package com.ust.member.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;


@Entity
public class Member {

	@Id
	@NotNull
  	@GeneratedValue
	int mbr_id;
	String f_name;
	String l_name;
	String dob;
	String gnr_cd;
	String mc_id;

	@OneToMany(fetch = FetchType.EAGER,mappedBy="member",cascade=CascadeType.ALL)
 	Set<Member_Contract> member_Contracts;

	// getters and setters

}
