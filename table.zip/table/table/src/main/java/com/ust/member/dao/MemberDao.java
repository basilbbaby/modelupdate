package com.ust.member.dao;

import java.util.List;

import com.ust.member.model.Member;

public interface MemberDao {

	public List<Member> diplayMember();

	public Member addMember(Member member);
}
