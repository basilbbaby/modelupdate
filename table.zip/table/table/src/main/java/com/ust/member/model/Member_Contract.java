package com.ust.member.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ForeignKey;

@Entity
public class Member_Contract {

	@Id
     @GeneratedValue
	int mem_cntrct_id;
	int scr_cd;
	int hc_id;
	String grp_id;
   	@ManyToOne(cascade= CascadeType.ALL)
    	@JoinColumn(name = "mbr_id")
	Member member;

		@OneToMany(fetch = FetchType.EAGER,mappedBy="membercontract",cascade=CascadeType.ALL)
 	Set<Member_coverage > member_coverage;
	

//getters and setters

	
}

